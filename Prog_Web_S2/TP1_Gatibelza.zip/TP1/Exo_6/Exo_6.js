var input = prompt("Entrez votre nom");
alert("bonjour " + input);