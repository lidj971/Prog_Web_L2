document.title="Bonjour!";
document.body.setAttribute("text","grey");